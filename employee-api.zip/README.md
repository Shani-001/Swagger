# JTRONIX Employee REST API

Employee REST API built for the JTRONIX Backend Internship Assessment using **Node.js** and **Express.js**.

---

## 1. Features Implemented

- **Employee Model & In-Memory Storage**:
  - Preloaded with sample employees (Rahul Sharma, Priya Patel, Amit Verma).
  - Model attributes: `id`, `name`, `department`, `status`.
- **Retrieve Employees (Q1.1)**:
  - `GET /employees`: Returns all employees as JSON.
  - `GET /employees/:id`: Returns an employee by ID; returns `404 Not Found` if nonexistent.
- **Add an Employee (Q1.2)**:
  - `POST /employees`: Accepts `name` and `department`, generates unique ID, defaults `status` to `Active`.
  - Validates non-empty `name` and `department` (returns `422 Unprocessable Entity` on validation failure).
  - Returns `201 Created` with new employee object.
- **Update and Filter Employees (Q1.3)**:
  - `PATCH /employees/:id/status`: Updates employee status to `Active` or `Inactive`.
  - Validates allowed statuses (returns `422` for invalid status, `404` for nonexistent ID).
  - `GET /employees?department=<name>`: Case-insensitive department filtering with whitespace handling.
- **Interactive Documentation**:
  - Swagger UI accessible at `/docs` (and `/api-docs`).

---

## 2. Setup & Installation

### Prerequisites
- Node.js (v18+ recommended, tested on v24)
- npm

### Install Dependencies
```bash
npm install
```

### Run the API
```bash
npm start
```
*The server will start on `http://127.0.0.1:8000`.*

---

## 3. Swagger UI Documentation

Access the interactive API documentation and test endpoints directly in your browser:
- **Swagger UI**: [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)

---

## 4. API Endpoints & Example Requests

| Method | Endpoint | Description | Status Code |
| :--- | :--- | :--- | :--- |
| `GET` | `/employees` | Retrieve all employees | `200 OK` |
| `GET` | `/employees?department=Engineering` | Filter employees by department | `200 OK` |
| `GET` | `/employees/:id` | Retrieve employee by ID | `200 OK` / `404 Not Found` |
| `POST` | `/employees` | Create employee (`name`, `department`) | `201 Created` / `422 Unprocessable` |
| `PATCH` | `/employees/:id/status` | Update employee status (`Active` / `Inactive`) | `200 OK` / `404` / `422` |

### Example cURL Commands

**Retrieve all employees:**
```bash
curl -X GET http://127.0.0.1:8000/employees
```

**Retrieve employee by ID:**
```bash
curl -X GET http://127.0.0.1:8000/employees/1
```

**Add a new employee:**
```bash
curl -X POST http://127.0.0.1:8000/employees \
  -H "Content-Type: application/json" \
  -d '{"name": "Sneha Rao", "department": "Design"}'
```

**Update employee status:**
```bash
curl -X PATCH http://127.0.0.1:8000/employees/1/status \
  -H "Content-Type: application/json" \
  -d '{"status": "Inactive"}'
```

**Filter by department:**
```bash
curl -X GET "http://127.0.0.1:8000/employees?department=Engineering"
```

*For more detailed request and response examples, refer to `examples/api_requests.md`.*

---

## 5. Automated Tests

Run the automated test suite using Jest and Supertest:

```bash
npm test
```

### Test Coverage
- `tests/employees.test.js`:
  - Retrieves all employees & verifies initial seed data.
  - Retrieves employee by ID.
  - Handles nonexistent and invalid employee IDs (returns 404).
  - Creates employee with auto-generated ID & default `Active` status (returns 201).
  - Rejects missing/empty names and departments (returns 422).
  - Updates status to `Active` and `Inactive` (returns 200).
  - Rejects invalid status values (returns 422).
  - Filters by department with case insensitivity and whitespace trimming.

---

## 6. Project Artifacts & Locations

- **Automated Tests**: `tests/employees.test.js`
- **Postman Collection**: `postman_collection.json`
- **API Request/Response Examples**: `examples/api_requests.md`
- **Swagger Specification**: `src/docs/swagger.json`
- **ZIP Submission Archive**: `employee-api.zip`

---

## 7. Submission Package (ZIP)

The submission archive `employee-api.zip` contains:
- `src/` (Source code: controllers, routes, in-memory store, swagger spec)
- `tests/` (Automated tests)
- `examples/` (API requests & examples)
- `postman_collection.json` (Postman Collection)
- `package.json` & `package-lock.json`
- `README.md`
- `.gitignore`

*(All `node_modules`, logs, and temporary caches are excluded).*
